//
//  readme.md
//  Virtual Tourist
//
//  Created by Edwina Granados on 11/19/19.
//  Copyright © 2019 Edwina Granados. All rights reserved.
//

import Foundation

This application extends the Virtual Tourist Application allowing users to create a note and add a picture from their album or camera. They can save, send, or add to social media. This allows users to basically say "I've been there."

This also incorporates the new log in using Apple API created in a recent release. When the user uses their log incredentials the name, user id (default), and the email pass to the application. The user can decide to obfuscate their actual email and send an Apple email link. 

Following the authentication the user will be taken to the map view of virtual tourist, then album view. Following that users click on the note button in the upper right corner and move to the notes.

The users can navigate back from notes to change their location.

This allowed me to begin implementing log in with Apple which will eventually become mandatory in the Apple Store. 

As a note, I also created my own apple icon and the launch screen pictures.

Step 1 click icon to launch the application
You will be presented with the launch screen - no action needed

Step 2 the Login View Controller will present next. Click on the Apple log in bar.
Next if you are already logged in to the iCloud you will be presented with the apple log on screen. Otherwise you will first be asked to log into the iCloud.
If you have enabled faceid on your mobile device it will login using face authentication you can also use touch authentication. Otherwise you will be asked to enter your password. You can choose to pass your email or pass a placeholder email. The system will call the Apple Authentication API and when you are verified it will segue to the navigation controller passing the user authentication. As a developer you could use the name passed in the application, however, I chose not to. The nav controller actions are not visible to the user.

Step 3 Next you will land on the Map View controller. The user will click on the information button in the nav bar for instructions. The user will long press on a map location. This will set a pin on that location. The user will click that pin which is saved on the map view until the user hits edit and deletes the pin. When the user clicks the pin a segue to the album view is performed.

Step 4 the user is presented with a smaller map of the location as a reminder. The user can see flickr photos of the location. The user can click a photo to delete it. The user can also click the button at the bottom to call a new set of photos. When the user is done on this screen the user can click the note button and segue to the note view controller.

Step 5 The user can overtype the instructions and enter a custom note about the location or a sort of 'I have been to the location' note detailing the experience. The user can also add a photo to the note. In my test, I had viewed Orlando. I added a picture I took of Orlando and a note about how I like the area. I then clicked share and texted the note to a friend.

Step 6 The user can return to the Album view controller and go back to add a different pin.



