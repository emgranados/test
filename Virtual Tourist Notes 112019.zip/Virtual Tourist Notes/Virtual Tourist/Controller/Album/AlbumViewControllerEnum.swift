//
//  AlbumViewControllerEnum.swift
//  Virtual Tourist
//
//  Created by Edwina Granados on 10/11/19.
//  Copyright © 2019 Edwina Granados. All rights reserved.
//

import Foundation

extension AlbumViewController {
    enum CellSelection {
        case selected
        case unselected
    }
}

