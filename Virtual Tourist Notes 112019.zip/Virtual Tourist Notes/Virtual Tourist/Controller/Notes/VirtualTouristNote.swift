//
//  VirtualTouristNote.swift
//  Virtual Tourist
//
//  Created by Edwina Granados on 11/17/19.
//  Copyright © 2019 Edwina Granados. All rights reserved.
//

import UIKit

struct VirtualTouristNote {
    let bottomText: String!
    let originalImage: UIImage!
    let finalImage: UIImage!
}
