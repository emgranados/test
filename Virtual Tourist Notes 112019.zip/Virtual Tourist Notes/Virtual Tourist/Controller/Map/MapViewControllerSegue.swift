//
//  MapViewControllerSegue.swift
//  Virtual Tourist
//
//  Created by Edwina Granados on 10/11/19.
//  Copyright © 2019 Edwina Granados. All rights reserved.
//


import Foundation
import UIKit

///extension MapViewController {
//    func openAlbumViewController(for place: Place) {
  //      DispatchQueue.main.async {
    //        let albumViewController = self.storyboard?.instantiateViewController(withIdentifier: "AlbumViewController") as! AlbumViewController
      //      albumViewController.place = place
            //self.navigationController?.pushViewController(albumViewController, animated: false)
     //   }
   // }
//}
 
