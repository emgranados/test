//
//  MainViewController.swift
//  Virtual Tourist
//
//  Created by Edwina Granados on 11/19/19.
//  Copyright © 2019 Edwina Granados. All rights reserved.
//

import UIKit

class MainViewController: UIViewController {
    
    var user: User?
    
    
    @IBOutlet weak var detailsLable: UILabel!
    
    @IBOutlet weak var nextButton: UIBarButtonItem!
    override func viewDidLoad() {
        super.viewDidLoad()
        detailsLable.text = user?.debugDescription ?? ""
    }
 
}
